package ru.vdl.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import android.util.Log
import androidx.core.app.NotificationCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

class DownloadService : Service() {
    private val executor = Executors.newSingleThreadExecutor()
    private val cancellationGeneration = AtomicLong(0L)
    private val pendingTasks = AtomicInteger(0)
    @Volatile private var currentProcessId: String? = null
    @Volatile private var lastExtractorOutput: String = ""
    @Volatile private var currentWakeLock: PowerManager.WakeLock? = null
    private lateinit var notificationManager: NotificationManager

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(NotificationManager::class.java)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                cancellationGeneration.incrementAndGet()
                currentProcessId?.let { id -> runCatching { YoutubeDL.getInstance().destroyProcessById(id) } }
                showStatus("Отмена загрузки…", 0, true, false)
                if (pendingTasks.get() == 0) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
                return START_NOT_STICKY
            }
            ACTION_DOWNLOAD -> {
                val url = intent.getStringExtra(EXTRA_URL).orEmpty()
                if (!isHttpUrl(url)) {
                    showStatus("Некорректная ссылка: нужен адрес http или https", 0, false, false)
                    if (pendingTasks.get() == 0) stopSelf(startId)
                    return START_NOT_STICKY
                }
                val generation = cancellationGeneration.get()
                val cookiesUri = intent.getStringExtra(EXTRA_COOKIES_URI)
                pendingTasks.incrementAndGet()
                startForegroundCompat(buildNotification("В очереди: ${pendingTasks.get()}", 0, true, true))
                executor.execute { download(url, cookiesUri, startId, generation) }
            }
        }
        return START_NOT_STICKY
    }

    private fun download(url: String, cookiesUri: String?, startId: Int, generation: Long) {
        if (generation != cancellationGeneration.get()) {
            finishTask(startId)
            return
        }
        val processId = "vdl-${System.currentTimeMillis()}"
        currentProcessId = processId
        val moviesDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?: run {
                showStatus("Не удалось получить каталог для временного видеофайла", 0, false, false)
                finishTask(startId)
                return
            }
        val outputDir = File(moviesDir, "VideoDownloader/$processId").apply { mkdirs() }
        lastExtractorOutput = ""
        try {
            val app = application as App
            if (!app.engineReady) {
                throw IllegalStateException("Загрузчик не инициализирован: ${app.engineError ?: "неизвестная ошибка"}")
            }
            acquireWakeLock()
            val cookiesFile = copyCookiesToPrivateFile(cookiesUri)
            val request = YoutubeDLRequest(url).apply {
                addOption("--no-playlist")
                addOption("--no-mtime")
                addOption("--newline")
                addOption("--retries", "10")
                addOption("--fragment-retries", "10")
                addOption("--extractor-retries", "3")
                addOption("--file-access-retries", "3")
                addOption("--socket-timeout", "30")
                addOption("--retry-sleep", "http:exp=1:20")
                addOption("--retry-sleep", "fragment:exp=1:20")
                addOption("--verbose")
                if (cookiesFile != null) addOption("--cookies", cookiesFile.absolutePath)
                addOption("--merge-output-format", "mp4")
                addOption("--recode-video", "mp4")
                addOption("-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best")
                addOption("-o", File(outputDir, "%(title).180B [%(id)s].%(ext)s").absolutePath)
            }
            val response = YoutubeDL.getInstance().execute(request, processId) { progress, eta, line ->
                lastExtractorOutput = line.takeLast(12_000)
                if (generation == cancellationGeneration.get()) {
                    val pct = progress.toInt().coerceIn(0, 100)
                    val statusLine = line.replace(Regex("\\u001B\\[[;\\d]*m"), "").trim()
                    showStatus(statusLine.take(120).ifBlank { "Загрузка: $pct% · ETA ${eta}s" }, pct, false)
                }
                Unit
            }
            if (generation != cancellationGeneration.get()) {
                showStatus("Загрузка отменена", 0, false, false)
            } else {
                val resultFile = newestCompletedFile(outputDir)
                if (resultFile != null && resultFile.length() > 0) {
                    val published = publishToMovies(resultFile)
                    showStatus(if (published != null) "Готово: сохранено в Movies/VideoDownloader" else "Готово: файл в папке приложения", 100, false, false)
                } else {
                    showStatus("Завершено, но готовый файл не найден. Проверь журнал yt-dlp.", 0, false, false)
                    Log.w(TAG, "yt-dlp response: ${response.out}")
                }
            }
        } catch (e: Exception) {
            val message = classifyError(e)
            Log.e(TAG, "Download failed: $message\n$lastExtractorOutput", e)
            showStatus(message, 0, false, false)
        } finally {
            currentProcessId = null
            releaseWakeLock()
            finishTask(startId)
        }
    }

    private fun finishTask(startId: Int) {
        val remaining = pendingTasks.decrementAndGet().coerceAtLeast(0)
        if (remaining == 0) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
        } else {
            showStatus("Осталось заданий в очереди: $remaining", 0, true, true)
        }
    }

    private fun copyCookiesToPrivateFile(uriString: String?): File? {
        if (uriString.isNullOrBlank()) return null
        val uri = Uri.parse(uriString)
        val target = File(cacheDir, "yt-dlp-cookies.txt")
        contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
            ?: throw IllegalStateException("Не удалось прочитать выбранный cookies-файл")
        return target
    }

    private fun acquireWakeLock() {
        if (currentWakeLock?.isHeld == true) return
        val powerManager = getSystemService(PowerManager::class.java)
        currentWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:download").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        runCatching { currentWakeLock?.takeIf { it.isHeld }?.release() }
        currentWakeLock = null
    }

    private fun newestCompletedFile(dir: File): File? = dir.listFiles()
        ?.filter { it.isFile && it.length() > 0 && it.extension.equals("mp4", ignoreCase = true) && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
        ?.maxByOrNull { it.lastModified() }

    private fun publishToMovies(source: File): Uri? {
        if (Build.VERSION.SDK_INT < 29) {
            val legacyDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "VideoDownloader")
            if (!legacyDir.exists()) legacyDir.mkdirs()
            val dest = File(legacyDir, source.name)
            source.copyTo(dest, overwrite = true)
            return Uri.fromFile(dest)
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, source.name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/VideoDownloader")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            contentResolver.openOutputStream(uri)?.use { output -> source.inputStream().use { it.copyTo(output) } }
                ?: throw IllegalStateException("Не удалось открыть файл назначения")
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            uri
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private fun classifyError(error: Throwable): String {
        val text = (error.message ?: error.toString()).lowercase()
        val output = lastExtractorOutput.lowercase()
        val combined = "$text\n$output"
        return when {
            "your ip address is blocked" in combined || "ip address is blocked" in combined -> "Сайт заблокировал запросы с текущего IP. Это ограничение сервера; попробуй позже или используй доступную официальную авторизацию."
            "impersonate target" in combined || "curl_cffi" in combined -> "Для этого сайта движку не хватает поддержки browser impersonation. Обнови yt-dlp; текущая сборка может не включать нужную зависимость."
            "no address associated" in combined || "unable to resolve host" in combined || "temporary failure in name resolution" in combined -> "Ошибка DNS: не удалось найти сервер. Проверь интернет или DNS."
            "403" in combined || "forbidden" in combined -> "Сайт отказал в доступе (HTTP 403). Проверь доступность видео и авторизацию."
            "429" in combined || "too many requests" in combined -> "Сайт ограничил частоту запросов (HTTP 429). Попробуй позже."
            "401" in combined || "unauthorized" in combined -> "Требуется авторизация на сайте."
            "ffmpeg" in combined || "postprocessing" in combined || "invalid data" in combined -> "Ошибка обработки видео. Источник мог вернуть не видеопоток или неподдерживаемый формат. Подробности доступны в журнале приложения."
            "не инициализирован" in text -> "Не удалось запустить загрузчик. Перезапусти приложение; если ошибка повторится, пришли журнал."
            else -> "Не удалось скачать: ${(error.message ?: error.javaClass.simpleName).take(180)}"
        }
    }

    private fun isHttpUrl(url: String) = url.startsWith("https://") || url.startsWith("http://")

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            notificationManager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW).apply {
                    description = getString(R.string.channel_description)
                }
            )
        }
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(text: String, progress: Int, indeterminate: Boolean, ongoing: Boolean): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("VideoDownloader")
            .setContentText(text)
            .setContentIntent(openAppIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
            .setProgress(100, progress, indeterminate)
        if (ongoing) {
            val cancelIntent = PendingIntent.getService(
                this, 1, Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Отменить", cancelIntent)
        }
        return builder.build()
    }

    private fun showStatus(text: String, progress: Int, indeterminate: Boolean, ongoing: Boolean = true) {
        notificationManager.notify(NOTIFICATION_ID, buildNotification(text, progress, indeterminate, ongoing))
    }

    // Android 15+ imposes a time budget on dataSync foreground services.
    // Stop cleanly instead of allowing a foreground-service timeout to crash the process.
    override fun onTimeout(startId: Int, fgsType: Int) {
        cancellationGeneration.incrementAndGet()
        currentProcessId?.let { id -> runCatching { YoutubeDL.getInstance().destroyProcessById(id) } }
        releaseWakeLock()
        showStatus("Android остановил длительную фоновую задачу по системному лимиту. Запусти загрузку повторно.", 0, false, false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        releaseWakeLock()
        executor.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val ACTION_DOWNLOAD = "ru.vdl.app.DOWNLOAD"
        const val ACTION_CANCEL = "ru.vdl.app.CANCEL"
        const val EXTRA_URL = "url"
        const val EXTRA_COOKIES_URI = "cookies_uri"
        private const val CHANNEL_ID = "downloads"
        private const val NOTIFICATION_ID = 2201
        private const val TAG = "VideoDownloader"
    }
}
