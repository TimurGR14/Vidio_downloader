package ru.vdl.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.yausername.youtubedl_android.YoutubeDL

class MainActivity : AppCompatActivity() {
    private lateinit var urlInput: EditText
    private lateinit var cookiesStatus: TextView
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val cookiesPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                prefs.edit().putString(KEY_COOKIES_URI, uri.toString()).apply()
                cookiesStatus.text = "Cookies: файл выбран"
                Toast.makeText(this, "Файл cookies подключён", Toast.LENGTH_SHORT).show()
            }.onFailure {
                cookiesStatus.text = "Cookies: не удалось сохранить доступ к файлу"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()
        buildScreen()
        intent?.getStringExtra(Intent.EXTRA_TEXT)?.let { shared ->
            if (shared.startsWith("http")) urlInput.setText(shared)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 32, 24, 24)
        }
        root.addView(TextView(this).apply {
            text = "VideoDownloader 2"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Вставь ссылку на видео. Загрузка продолжится в фоне, а результат появится в папке Movies/VideoDownloader."
            textSize = 15f
            setPadding(0, 16, 0, 20)
        })
        urlInput = EditText(this).apply {
            hint = "https://…"
            singleLine = false
            minLines = 2
            setTextIsSelectable(true)
        }
        root.addView(urlInput, LinearLayout.LayoutParams(-1, -2))
        cookiesStatus = TextView(this).apply {
            text = if (prefs.getString(KEY_COOKIES_URI, null) == null) "Cookies: не используются" else "Cookies: файл выбран"
            textSize = 13f
            setPadding(0, 12, 0, 4)
        }
        root.addView(cookiesStatus, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "Используй cookies.txt в формате Netscape, экспортированный из своего браузера. Файл хранится в закрытой папке приложения и применяется только к твоим загрузкам. Не передавай cookies другим людям."
            textSize = 11f
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply {
            text = "Выбрать cookies.txt (необязательно)"
            setOnClickListener { cookiesPicker.launch(arrayOf("text/plain", "application/octet-stream", "*/*")) }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        root.addView(Button(this).apply {
            text = "Удалить cookies"
            setOnClickListener {
                prefs.edit().remove(KEY_COOKIES_URI).apply()
                cookiesStatus.text = "Cookies: не используются"
                Toast.makeText(this@MainActivity, "Cookies отключены", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 4 })
        root.addView(Button(this).apply {
            text = "Обновить yt-dlp (Stable)"
            setOnClickListener { updateYtDlp() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        root.addView(Button(this).apply {
            text = "Скачать MP4"
            setOnClickListener { startDownload() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        root.addView(Button(this).apply {
            text = "Отменить текущую загрузку"
            setOnClickListener {
                startService(Intent(this@MainActivity, DownloadService::class.java).setAction(DownloadService.ACTION_CANCEL))
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        root.addView(TextView(this).apply {
            text = "Поддержка зависит от сайта, доступности видео и разрешений владельца. DRM и закрытые материалы не обходятся."
            textSize = 12f
            setPadding(0, 24, 0, 0)
        })
        setContentView(root)
    }

    private fun startDownload() {
        val url = urlInput.text.toString().trim()
        if (!url.startsWith("https://") && !url.startsWith("http://")) {
            urlInput.error = "Вставь корректную ссылку http или https"
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Разреши уведомления, чтобы видеть ход фоновой загрузки", Toast.LENGTH_LONG).show()
            requestNotificationPermissionIfNeeded()
        }
        val serviceIntent = Intent(this, DownloadService::class.java)
            .setAction(DownloadService.ACTION_DOWNLOAD)
            .putExtra(DownloadService.EXTRA_URL, url)
            .putExtra(DownloadService.EXTRA_COOKIES_URI, prefs.getString(KEY_COOKIES_URI, null))
        ContextCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, "Загрузка запущена. Она отображается в уведомлениях.", Toast.LENGTH_LONG).show()
    }

    private fun updateYtDlp() {
        Toast.makeText(this, "Проверяю обновление yt-dlp…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val status = YoutubeDL.getInstance().updateYoutubeDL(this, YoutubeDL.UpdateChannel.STABLE)
                val version = YoutubeDL.getInstance().versionName(this)
                runOnUiThread {
                    Toast.makeText(this, "yt-dlp: $status · версия $version", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Не удалось обновить yt-dlp: ${e.message ?: "ошибка сети"}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
        }
    }
    companion object { private const val KEY_COOKIES_URI = "cookies_uri" }
}
