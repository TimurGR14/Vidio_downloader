package ru.vdl.app

import android.app.Application
import android.util.Log
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL

class App : Application() {
    @Volatile var engineReady: Boolean = false
        private set
    @Volatile var engineError: String? = null
        private set

    override fun onCreate() {
        super.onCreate()
        try {
            YoutubeDL.getInstance().init(this)
            FFmpeg.getInstance().init(this)
            engineReady = true
            engineError = null
        } catch (e: Exception) {
            engineReady = false
            engineError = e.message ?: e.javaClass.simpleName
            Log.e("VideoDownloader", "Не удалось инициализировать yt-dlp/FFmpeg", e)
        }
    }
}
