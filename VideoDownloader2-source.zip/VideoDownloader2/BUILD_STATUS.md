# VideoDownloader 2.0 — build status

Date: 2026-11-26

## Completed in source

- New Android project (not a binary patch of the original APK).
- yt-dlp Android wrapper 0.18.1 + FFmpeg wrapper 0.18.1.
- Foreground `dataSync` service, notification progress and cancellation action.
- Sequential queue for multiple submitted URLs.
- Optional Netscape `cookies.txt` import.
- MP4 format preference and FFmpeg remux/recode path.
- MediaStore publication into `Movies/VideoDownloader` on Android 10+.
- Better classification of DNS, IP block, HTTP auth/rate limit, impersonation and postprocessing failures.
- Android 15+ foreground-service timeout callback.

## Validation actually performed

- Source files and project layout inspected.
- yt-dlp Android API compared with upstream sample; the callback is a three-argument callback `(progress, eta, line)` and process id is passed to `execute`.
- XML validation is run before packaging the source archive.

## Not validated

- No successful Gradle build.
- No APK produced.
- No installation or runtime test on an Android device.
- No end-to-end test of TikTok, VK or the supplied adult-site URL.

Reason: this build container has no Android SDK/Gradle installation and cannot resolve `services.gradle.org` (DNS/network unavailable). The included GitHub Actions workflow can produce a debug APK once this project is pushed to a GitHub repository with Actions enabled.

## Known platform/site limits

- A website may block the current IP, require an authorized session, or change its extractor; no downloader can guarantee all URLs.
- DRM-protected streams and content without authorized access are not supported.
- Android 15+ applies a time budget to `dataSync` foreground services. The current implementation handles timeout cleanly, but does not yet migrate to the User-Initiated Data Transfer API.
- Queue is in-memory and does not survive process death/reboot.
